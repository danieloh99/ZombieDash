#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor : public GraphObject {
public:
	StudentWorld* getWorld() const { return m_world; }
	Actor(StudentWorld* world, int imageID, double startX, double startY, Direction dir, int depth);
	virtual ~Actor() {}
	
	virtual bool isAlive() const;
	virtual void setDead();

	virtual bool blocksMovement() const; // Returns true for blockers, false for non-blockers.
	virtual bool canExit() const; // Returns true for only humans
	
	virtual void doSomething() = 0;
private:
	StudentWorld* m_world;
	bool m_alive;
};

// Abstract Base for Player and Citizen classes.
class Human : public Actor {
public:
	// Constructor, Destructor
	Human(StudentWorld* world, int imageID, double startX, double startY);
	virtual ~Human();

	virtual bool blocksMovement() const;
	virtual bool canExit() const;
	
	void checkInfection();

	// Getters
	bool isInfected() const;
	int getInfectionCount() const;
	// Setters
	void setInfectionStatus(bool status);
	void incInfectionCount();
private:
	bool infectionStatus;
	int infectionCount;
};

class Player : public Human {
public:
	// Constructor, Destructor
	Player(StudentWorld* world, double startX, double startY);
	virtual ~Player();
	
	virtual void setDead();

	virtual void doSomething();

	// Getters
	int getLandmines() const;
	int getFlames() const;
	int getVaccines() const;
	// Setters (if player uses resource, pass in negative integer)
	void incLandmines(int howMuch);
	void incFlames(int howMuch);
	void incVaccines(int howMuch);
private:
	int numLandmines;
	int numFlames;
	int numVaccines;
};

class Citizen : public Human {
public:
	Citizen(StudentWorld* world, double startX, double startY);
	virtual ~Citizen();

	virtual void doSomething();
	
	//Getters
	bool getParalyzedStatus();
	//Setters
	void setParalyzedStatus(bool status);
private:
	bool paralyzed;
};

class Wall : public Actor {
public:
	Wall(StudentWorld* world, double xPos, double yPos);
	virtual ~Wall();

	virtual bool blocksMovement() const;

	virtual void doSomething();
};

class Exit : public Actor {
public:
	Exit(StudentWorld* world, double xPos, double yPos);
	virtual ~Exit();

	virtual void doSomething();
};
#endif // ACTOR_H_
