#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GraphObject.h" // for Direction
#include <string>
#include <vector>
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class Player;
class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
	~StudentWorld();
    virtual int init();
    virtual int move();
    virtual void cleanUp();

	int getNumCitizens() const;
	void setFinishedLevelTrue();
	bool blockingActorExists(const Actor* mover); // Determining blocking of movement

	// Consider changing to simply pass in position, rather than pointer to entire actor.
	bool overlapsWithCitizen(const Actor* overlapee); // Determines if actor overlaps with Citizen.
	bool overlapsWithPlayer(const Actor* overlapee); // Determines if actor overlaps with Player.

	double distanceFromPlayer(double actorX, double actorY);
	bool sameRowOrColPlayer(double actorX, double actorY);
private:
	Player* m_penelope;
	std::vector<Actor*> allActors; // list of all the Actors (not including Penelope).

	int numCitizens;
	bool finishedLevel;

	// Helper functions for determining blocking of movement
	bool inHeightRange(double moverBottom, double moverTop, double blockerBottom, double blockerTop) const;
	bool inWidthRange(double moverLeft, double moverRight, double blockerLeft, double blockerRight) const;

	// Helper function for all overlap functions
	bool doesOverlap(const Actor* overlapper, const Actor* overlapee);
};

#endif // STUDENTWORLD_H_
