#include "StudentWorld.h"
#include "GameConstants.h"
#include "Level.h"
#include "Actor.h"
#include <vector>
#include <string>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}
StudentWorld::~StudentWorld() {
	cleanUp();
}
int StudentWorld::init()
{
	Level lev(assetPath()); // Makes an empty 16x16 grid.

	// Probably want to change this, if level is finished. Use getLevel() in GameWorld.h
	int levelInt = getLevel();
	string levelFile;
	if (levelInt < 10) {
		levelFile = "level0" + to_string(levelInt) + ".txt";
	}
	else
		levelFile = "level" + to_string(levelInt) + ".txt";

	Level::LoadResult result = lev.loadLevel(levelFile); // Attempt to load the level

	// If level doesn't load:
	if (result == Level::load_fail_file_not_found)
		cerr << "Cannot find " << levelFile << " data file" << endl;
	else if (result == Level::load_fail_bad_format)
		cerr << "Your level was improperly formatted" << endl;
	// If the level does load:
	else if (result == Level::load_success) {
		cerr << "Successfully loaded " << levelFile << endl;
		
		finishedLevel = false; // When the level is loaded, it starts unfinished.
		int numObjectsCreated = 0; // DEBUGGING PURPOSES

		// Read the level file
		Level::MazeEntry gameObject;
		for (int i = 0; i < LEVEL_HEIGHT; i++) {
			for (int j = 0; j < LEVEL_WIDTH; j++) {
				gameObject = lev.getContentsOf(i, j); // Reads char in text file, assigns to gameObject
				cerr << "Location " << i * SPRITE_WIDTH << "," << j * SPRITE_HEIGHT;

				switch (gameObject) {
				case Level::empty:
					cerr << " is empty." << endl;
					break;
				case Level::player: {
					cerr << " is where Penelope starts." << endl;
					m_penelope = new Player(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT);
					numObjectsCreated++; // DEBUGGING PURPOSES
					break;
				}
				case Level::wall: {
					cerr << " holds a wall." << endl;
					allActors.push_back(new Wall(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
					numObjectsCreated++; // DEBUGGING PURPOSES
					break;
				}
				case Level::exit: {
					cerr << " holds an exit." << endl;
					allActors.push_back(new Exit(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
					numObjectsCreated++; // DEBUGGING PURPOSES
					break;
				}
				case Level::citizen: {
					cerr << " starts with a citizen." << endl;
					allActors.push_back(new Citizen(this, i * SPRITE_WIDTH, j * SPRITE_HEIGHT));
					numObjectsCreated++; // DEBUGGING PURPOSES
					break;
				}
				default: {
					cerr << " holds a different object." << endl;
					break;
				}
				}
			}
		} // Finish reading level
		cerr << "Num Objects Created: " << numObjectsCreated << endl; // DEBUGGING PURPOSES
		numCitizens = 0;
		cerr << "Num Citizens is currently " << numCitizens << ". Probably change this.\n";
	}
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	m_penelope->doSomething();
	if (!m_penelope->isAlive()) {
		return GWSTATUS_PLAYER_DIED;
	}
	vector<Actor*>::iterator it = allActors.begin();
	while (it != allActors.end()) {
		if ((*it)->isAlive())
			(*it)->doSomething();
		if (!m_penelope->isAlive()) {
			return GWSTATUS_PLAYER_DIED;
		}
		else if (finishedLevel)
			return GWSTATUS_FINISHED_LEVEL;
		it++;
	}

	// Remove newly-dead actors after each tick
	it = allActors.begin();
	while (it != allActors.end()) {
		if (!(*it)->isAlive()) {
			delete *it;
			it = allActors.erase(it);
		}
		it++;
	}
	// Update the game status line
		// Add Score, Level, Lives, Vacc, Flames, Mines, Infected in that order.
		// Use setGameStatText(string)
	setGameStatText("Score: " + to_string(getScore()) + "  Level: " + to_string(getLevel())
		+ "  Lives: " + to_string(getLives()) + "  Vacc: " + to_string(m_penelope->getVaccines())
		+ "  Flames: " + to_string(m_penelope->getFlames()) + "  Mines: " + to_string(m_penelope->getLandmines())
		+ "  Infected: " + to_string(m_penelope->getInfectionCount()) );

	// the player hasn�t completed the current level and hasn�t died, so
	// continue playing the current level
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	int numObjectsDestroyed = 0; // DEBUGGING PURPOSES
	vector<Actor*>::iterator it = allActors.begin();
	while (it != allActors.end()) {
		delete *it;
		it = allActors.erase(it);
		numObjectsDestroyed++; // DEBUGGING PURPOSES
	}
	delete m_penelope;
	numObjectsDestroyed++;
	cerr << "Num objects destroyed: " << numObjectsDestroyed << endl; // DEBUGGING PURPOSES
	cout << "Vector size after destruction: " << allActors.size() << endl; // DEBUGGING PURPOSES
}

int StudentWorld::getNumCitizens() const { return numCitizens; }
void StudentWorld::setFinishedLevelTrue() { finishedLevel = true; }


// Called each time a moving actor attempts to move
bool StudentWorld::blockingActorExists(const Actor* mover) {

	// Get mover's direction and position
	Direction dir = mover->getDirection();
	double moverBottom = mover->getY();
	double moverTop = mover->getY() + SPRITE_HEIGHT - 1;
	double moverLeft = mover->getX();
	double moverRight = mover->getX() + SPRITE_WIDTH - 1;

	double blockerBottom = 0;
	double blockerTop = 0;
	double blockerLeft = 0;
	double blockerRight = 0;

	vector<Actor*>::iterator it = allActors.begin();

	while (it != allActors.end()) { 
		// Go through allActors until reaching an actor that blocks movement
		if ((*it)->blocksMovement()) {

			// Store boundaries of blocker
			blockerBottom = (*it)->getY();
			blockerTop = (*it)->getY() + SPRITE_HEIGHT - 1;
			blockerLeft = (*it)->getX();
			blockerRight = (*it)->getX() + SPRITE_WIDTH - 1;

			switch (dir) {

			case mover->left:
				// If the blocker's right side to the right of the mover's left side
				// ignore the blocker.
				if (blockerRight >= moverLeft)
					break;

				// If the blocker's right side is equal to or past the left side of the
				// mover's new position and mover's yPos is within the blocker's y-Range, return true.
				if (blockerRight >= moverLeft - 4 &&
					inHeightRange(moverBottom, moverTop, blockerBottom, blockerTop))
					return true;
				break;

			case mover->right:
				// If the blocker's left side to the left of the mover's right side
				// ignore the blocker.
				if (blockerLeft <= moverRight)
					break;
				// If the blocker's left side is equal to or past the right side of the
				// mover's new position and mover's yPos is within the blocker's y-Range, return true.
				if (blockerLeft <= moverRight + 4 &&
					inHeightRange(moverBottom, moverTop, blockerBottom, blockerTop))
					return true;
				break;

			case mover->up:
				// If the blocker's bottom is below the mover's top, ignore the blocker.
				if (blockerBottom <= moverTop)
					break;
				// If the blocker's bottom is past the top side of the mover's 
				// new position and mover's xPos is within the blocker's x-Range, return true.
				if (blockerBottom <= moverTop + 4 &&
					inWidthRange(moverLeft, moverRight, blockerLeft, blockerRight))
					return true;
				break;

			case mover->down:
				// If the blocker's top is above the mover's bottom, ignore the blocker.
				if (blockerTop >= moverBottom)
					break;
				// If the blocker's top is past the bottom side of the mover's 
				// new position and mover's xPos is within the blocker's x-Range, return true.
				if (blockerTop >= moverBottom - 4 &&
					inWidthRange(moverLeft, moverRight, blockerLeft, blockerRight))
					return true;
				break;
			}
		}
		it++;
	}

	return false;
}

bool StudentWorld::overlapsWithCitizen(const Actor* overlapee) {
	vector<Actor*>::iterator it = allActors.begin();
	// In the container of allActors, only citizens can Exit.
	while (it != allActors.end()) {
		if ((*it)->canExit() && doesOverlap(*it, overlapee))
			return true;
		it++;
	}
	return false;
}
bool StudentWorld::overlapsWithPlayer(const Actor* overlapee) {
	return doesOverlap(m_penelope, overlapee);
}
bool StudentWorld::doesOverlap(const Actor* overlapper, const Actor* overlapee) {
	/* 
	In Zombie Dash, two objects are said to overlap if the Euclidean distance between their
	(x,y) centers is less than or equal to 10 pixels (i.e., if (dx)^2 + (dy)^2 <= 10^2)
	*/

	/* Idea: Pass in 1 actor. do switch case, for different types of actors.
		Different actors want to check for different overlaps.
		There's no way passing in 2 actors works, because you'd need the address
		of the 2nd actor, which you wouldn't have when calling the function.	
	*/

	double overlapeeCenterX = (2 * overlapee->getX() + SPRITE_WIDTH - 1) / 2;
	double overlapeeCenterY = (2 * overlapee->getY() + SPRITE_HEIGHT - 1) / 2;
	double overlapperCenterX = (2 * overlapper->getX() + SPRITE_WIDTH - 1) / 2;
	double overlapperCenterY = (2 * overlapper->getY() + SPRITE_HEIGHT - 1) / 2;
	
	return (pow(overlapperCenterX - overlapeeCenterX, 2) + 
		pow(overlapperCenterY - overlapeeCenterY, 2) <= 100);

	//vector<Actor*>::iterator it = allActors.begin();
	//while (it != allActors.end()) {
	//	if ((*it) != actor) { // All actors that don't block movement can overlap.
	//		overlapperCenterX = (2 * (*it)->getX() + SPRITE_WIDTH - 1) / 2;
	//		overlapperCenterY = (2 * (*it)->getY() + SPRITE_HEIGHT - 1) / 2;
	//		if (pow(overlapperCenterX - a1centerX, 2) + pow(overlapperCenterY - a1centerY, 2) <= 100) {
	//			cerr << "Overlapper Position: " << (*it)->getX() << "," << (*it)->getY() << endl;
	//			return true;
	//		}
	//	}
	//	it++;
	//}
	//
	//return false;
}

double StudentWorld::distanceFromPlayer(double actorX, double actorY) {
	double xDist = m_penelope->getX() - actorX;
	double yDist = m_penelope->getY() - actorY;
	return ( sqrt(pow(xDist, 2) + pow(yDist, 2)) );
}
bool StudentWorld::sameRowOrColPlayer(double actorX, double actorY) {
	return (actorX == m_penelope->getX() || actorY == m_penelope->getY());
}

// Private function, checks if mover's yPos is within the blocker's y-Range
bool StudentWorld::inHeightRange(double moverBottom, double moverTop, double blockerBottom, double blockerTop) const {
	return ( (moverBottom >= blockerBottom && moverBottom <= blockerTop) ||
		(moverTop >= blockerBottom && moverTop <= blockerTop) );
}
// Private function, checks if mover's xPos is within the blocker's x-Range
bool StudentWorld::inWidthRange(double moverLeft, double moverRight, double blockerLeft, double blockerRight) const {
	return ( (moverLeft >= blockerLeft && moverLeft <= blockerRight) ||
		(moverRight >= blockerLeft && moverRight <= blockerRight) );
}