#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
#include <iostream>
#include "GameWorld.h"
using namespace std;

// Actor implementations
Actor::Actor(StudentWorld* world, int imageID, double startX, double startY, Direction dir = right, int depth = 0) 
	: m_world(world), m_alive(true), GraphObject(imageID, startX, startY, dir, depth) {}

// Living status accessor and setter
bool Actor::isAlive() const { return m_alive; }
void Actor::setDead() { m_alive = false; }

bool Actor::blocksMovement() const { return false; } // Distinguish between blockers and non-blockers
bool Actor::canExit() const { return false; } // Distinguish between humans and non-humans

// Human implementations: base for Player and Citizen
Human::Human(StudentWorld* world, int imageID, double startX, double startY)
	: Actor(world, imageID, startX, startY) {
	infectionStatus = false;
	infectionCount = 0;
}
Human::~Human() {}
bool Human::blocksMovement() const { return true; } // Will eventually go to Movers Class
bool Human::canExit() const { return true; }

void Human::checkInfection() {
	// cerr << "Checking if human is infected.\n";
	if (isInfected()) {
		// cerr << "Human is infected. Increasing infection count.\n";
		incInfectionCount();
	}
}
// Getters
bool Human::isInfected() const { return infectionStatus; }
int Human::getInfectionCount() const { return infectionCount; }
// Setters
void Human::setInfectionStatus(bool status) { infectionStatus = status; }
void Human::incInfectionCount() { infectionCount++; }

// Player implementations
Player::Player(StudentWorld* world, double startX, double startY) 
	: numLandmines(0), numFlames(0), numVaccines(1), Human(world, IID_PLAYER, startX, startY) {}
Player::~Player() { cerr << "Destroying Penelope at " << getX() << "," << getY() << endl; }
void Player::setDead() {
	//getWorld()->decLives();
	Actor::setDead();
}
// Getters
int Player::getLandmines() const { return numLandmines; }
int Player::getFlames() const {	return numFlames; }
int Player::getVaccines() const { return numVaccines; }
// Setters (if player uses resource, pass in negative integer)
void Player::incLandmines(int howMuch) { numLandmines += howMuch; }
void Player::incFlames(int howMuch) { numFlames += howMuch; }
void Player::incVaccines(int howMuch) { numVaccines += howMuch; }

void Player::doSomething() {

	// If player is dead, return immediately
	// cerr << "Checking if player is dead.\n";
	if (!isAlive()) {
		// cerr << "Player is dead. Finishing Player doSomething().\n";
		return;
	}
	// cerr << "Starting Human checkInfection().\n";
	Human::checkInfection();
	// cerr << "Finished Human checkInfection().\n";

	// cerr << "Checking player's infection count == 500.\n";
		if (getInfectionCount() == 500) {
			cerr << "Player's infection count == 500.\n";
			cerr << "Setting player dead.\n";
			setDead();
			cerr << "Decreasing Lives.\n";
			getWorld()->decLives();
			getWorld()->playSound(SOUND_PLAYER_DIE);
			return;
		}
//	}
	
	// If user presses a key during the tick
	int ch;
	if (getWorld()->getKey(ch))
	{
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			cerr << "left" << endl;

			GraphObject::setDirection(left);
			// If (there are no blocking actors at xpos getX() - 4)
			if (getWorld()->blockingActorExists(this) == false)
				GraphObject::moveTo(getX() - 4, getY());
			break;
		case KEY_PRESS_RIGHT:
			cerr << "right" << endl;

			GraphObject::setDirection(right);
			// If (there are no blocking actors at x-pos: getX() + 4)
			if (getWorld()->blockingActorExists(this) == false)
				GraphObject::moveTo(getX() + 4, getY());
			break;
		case KEY_PRESS_DOWN:
			cerr << "down" << endl;

			GraphObject::setDirection(down);
			// if (there are no blocking actors at y-pos: getY() - 4)
			if (getWorld()->blockingActorExists(this) == false)
				GraphObject::moveTo(getX(), getY() - 4);
			break;
		case KEY_PRESS_UP:
			cerr << "up" << endl;

			GraphObject::setDirection(up);
			// if (there are no blocking actors at y-pos: getY() + 4)
			if (getWorld()->blockingActorExists(this) == false)
				GraphObject::moveTo(getX(), getY() + 4);
			break;
		case KEY_PRESS_SPACE:
			cerr << "space: Fire!" << endl;
			if (numFlames > 0) {
				numFlames--;
				getWorld()->playSound(SOUND_PLAYER_FIRE);
				// add flames in front of Penelope
				cerr << "flames created!" << endl;
			}
			break;
		case KEY_PRESS_TAB:
			cerr << "tab: Landmine!" << endl;
			if (numLandmines > 0) {
				// add landmine object at Player's location
				cerr << "landmine placed!" << endl;
				numLandmines--;
			}
			break;
		case KEY_PRESS_ENTER:
			cerr << "enter: Vaccine!" << endl;
			if (numVaccines > 0) {
				setInfectionStatus(false);
				cerr << "vaccines used!" << endl;
				numVaccines--;
			}
			break;
		}
	}
	return;
}

Citizen::Citizen(StudentWorld* world, double startX, double startY)
	: Human(world, IID_CITIZEN, startX, startY), paralyzed(false) {}
Citizen::~Citizen() { cerr << "Destroying Citizen at " << getX() << "," << getY() << endl; }
bool Citizen::getParalyzedStatus() { return paralyzed; }
void Citizen::setParalyzedStatus(bool status) { paralyzed = status; }
void Citizen::doSomething() {
	// Check if alive
	if (!isAlive())
		return;
	// Check infection status, update if necessary.
	Human::checkInfection();
	if (getInfectionCount() == 500) {
		setDead();
		getWorld()->playSound(SOUND_ZOMBIE_BORN); // Play sound effect
		getWorld()->increaseScore(-1000); // Decrease score by 1000
		// Add zombie object at Citizen's position to Student World
			// 70% chance for dumb zombie, 30% chance for smart zombie
		return;
	}
	// Every other tick, Citizen is paralyzed. If paralyzed, do nothing.
	paralyzed = !paralyzed;
	if (paralyzed) return;

	cerr << "Determining distance from Penelope.\n";
	double distP = getWorld()->distanceFromPlayer(getX(),getY());
	// Step 5: Determine distance from closest zombie
	double distZ = -1; // function should return -1 if there are no zombies

	// Step 6: Determine citizen's movement
	if ((distP < distZ || distZ == -1) && distP <= 80) {
		// If the citizen is on the same row or column as the Player
		if (getWorld()->sameRowOrColPlayer(getX(), getY())) {
			/*
				i. If the citizen can move 2 pixels in the direction toward Penelope
				without being blocked16 (by another citizen, Penelope, a zombie, or
				a wall), the citizen will
					1. Set its direction to be facing toward Penelope.
					2. Move 2 pixels in that direction using the GraphObject
					class's moveTo() method.
					3. Immediately return and do nothing more during the current
					tick.
			*/
			Direction dirToPlayer = right; // change to getDirToPlayer();
			setDirection(dirToPlayer);
			return;
		}
		// Make citizen follow Penelope


		//Direction dirToPlayer = 0 /*getDirectionTowardPlayer()*/;
		//switch (dirToPlayer) {
		//case right:
		//}
	}



}

// Wall implementations
Wall::Wall(StudentWorld* world, double xPos, double yPos)
	: Actor(world, IID_WALL, xPos, yPos) {}
Wall::~Wall() { cerr << "Destroying Wall at " << getX() << "," << getY() << endl; }
bool Wall::blocksMovement() const { return true; }
void Wall::doSomething() { return; }

// Exit implementations
Exit::Exit(StudentWorld* world, double xPos, double yPos) 
	: Actor(world, IID_EXIT, xPos, yPos, right, 1) {}
Exit::~Exit() { cerr << "Destroying Exit at " << getX() << "," << getY() << endl; }
void Exit::doSomething() {
	
	// If the exit overlaps with a citizen
	if (getWorld()->overlapsWithCitizen(this)) {
		cerr << "exit detects citizen overlapper" << endl;
		
		// Inform the StudentWorld object that the user is to receive 500 points.
		
		/*
		Set the citizen object�s state to dead (so that it will be removed from the game
		by the StudentWorld object at the end of the current tick) � note, this must
		not kill the citizen in a way that deducts points from the player as if the
		citizen died due to a zombie infection, a flame, or a pit.
		*/

		// Play a sound effect for saving a citizen.
		getWorld()->playSound(SOUND_CITIZEN_SAVED);
	}

	// If the exit overlaps with the player
	if (getWorld()->overlapsWithPlayer(this)) {

		// If there are no citizens remaining
		if (getWorld()->getNumCitizens() == 0) {
			cerr << "Player exitted" << endl;

			// Play sound effect for finishing level and tell StudentWorld level is finished
			getWorld()->playSound(SOUND_LEVEL_FINISHED);
			getWorld()->setFinishedLevelTrue();
		}
		else {
			cerr << "Player may not exit, number of citizens remaining: " <<
				getWorld()->getNumCitizens() << endl;
		}
	}
}